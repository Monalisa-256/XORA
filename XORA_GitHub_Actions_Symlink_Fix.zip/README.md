# XORA GitHub Actions ZIP/Next.js Symlink Fix

**Bug verified:** GitHub Actions run #7 failed at ZIP sync after a successful Next.js build because `scripts/zip_guard.py` rejected `.next/node_modules/@aws-sdk/client-s3-ecbef8e33fd0b8f0` before checking that `.next` is an excluded generated build directory.

## Install

Extract this ZIP **directly into the root** of `Monalisa-256/XORA`, preserving the `.github` hidden directory, then commit the three changed files:

- `scripts/zip_guard.py` — durable fix: `os.walk(..., followlinks=False)` prunes `.next`, `node_modules`, `dist`, and other build/dependency directories before checking symlinks. Non-ignored source symlinks remain rejected.
- `tests/test_zip_guard.py` — adds four regression tests: Next.js symlink exclusion, strict sync with generated symlink, and continued rejection of source-file and source-directory symlinks.
- `.github/workflows/zip-extract-validate-update.yml` — defense in depth: removes `.next`, `node_modules`, `.turbo`, and `coverage` after the successful Next.js build and before archive sync. Existing CI tests and safe ZIP checks are preserved.

`README.md` and `scripts/verify_repo.py` are included as information/dependency; verifier is unchanged.

For a **one-file immediate workaround**, edit the workflow only and add this step immediately before "Normalize each ZIP independently":

```yaml
      - name: Remove generated build and dependency directories before ZIP refresh
        shell: bash
        run: |
          set -euo pipefail
          rm -rf -- .next node_modules .turbo coverage
```

The durable extractor change is still recommended because packaging could be run outside this workflow too.

## Local validation evidence

- 43 Python unit tests passed (39 original + 4 new).
- YAML parsed successfully; both workflow jobs remained present.
- End-to-end synthetic Next.js build-artifact symlink simulation successfully normalized **both real XORA archive names independently** and passed the repository validator with `--require-root-layout --no-duplicate-content`.
- The output ZIPs omitted generated directories, preserved source structure, contained SHA-256 manifests, and had no nested ZIPs/duplicate paths.

**GitHub remote status:** The GitHub connector returns HTTP 403 `Resource not accessible by integration` for repository file edits. This fix is locally verified, but it has not yet been applied to your GitHub `main` branch through the connector. Paste/upload and commit the files with a GitHub account with repository write access. Then rerun the workflow.
