import 'server-only';
import type {PoolClient} from 'pg';
import {getPool} from './db';
import {isUuid} from '@/core/security';
import type {ProfileDraft} from '@/core/onboarding';

/** Actor-scoped RLS context only inside a transaction (safe with Neon pooled connections). */
export async function withMemberTransaction<T>(accountId:string, callback:(client:PoolClient)=>Promise<T>):Promise<T>{
  if(!isUuid(accountId))throw Error('INVALID_ACTOR');
  const client=await getPool().connect();
  let committed=false;
  try{
    await client.query('BEGIN');
    await client.query("SELECT set_config('xora.actor_account_id',$1,true)",[accountId]);
    const result=await callback(client);
    await client.query('COMMIT');committed=true;
    return result;
  }finally{
    if(!committed)await client.query('ROLLBACK').catch(()=>{});
    client.release();
  }
}
export type SafeDraft={display_name:string;broad_area:string;intention:string;bio:string;review_state:string;version:number;updated_at:string};
export async function getMemberDraft(accountId:string):Promise<SafeDraft|null>{
  return withMemberTransaction(accountId,async c=>{
    const r=await c.query('SELECT display_name,broad_area,intention,bio,review_state,version,updated_at FROM member_profiles WHERE account_id=$1',[accountId]);
    return r.rows[0]??null;
  });
}
export async function saveMemberDraft(accountId:string,draft:ProfileDraft):Promise<SafeDraft|null>{
  return withMemberTransaction(accountId,async c=>{
    // v0 creates a new draft. A concurrent create cannot be mistaken for a matching v0 update.
    if(draft.expected_version===0){
      const inserted=await c.query(`INSERT INTO member_profiles(account_id,display_name,broad_area,intention,bio)
        VALUES($1,$2,$3,$4,$5) ON CONFLICT(account_id) DO NOTHING
        RETURNING display_name,broad_area,intention,bio,review_state,version,updated_at`,
      [accountId,draft.display_name,draft.broad_area,draft.intention,draft.bio]);
      if(inserted.rows[0]){
        await c.query('INSERT INTO member_privacy_settings(account_id) VALUES($1) ON CONFLICT(account_id) DO NOTHING',[accountId]);
        return inserted.rows[0];
      }
      return null;
    }
    const updated=await c.query(`UPDATE member_profiles SET
      display_name=$2,broad_area=$3,intention=$4,bio=$5,version=version+1,updated_at=now()
      WHERE account_id=$1 AND version=$6 AND review_state IN ('draft','needs_changes')
      RETURNING display_name,broad_area,intention,bio,review_state,version,updated_at`,
      [accountId,draft.display_name,draft.broad_area,draft.intention,draft.bio,draft.expected_version]);
    return updated.rows[0]??null;
  });
}
export type SafePrivacyRequest={id:string;kind:string;state:string;created_at:string};
export async function listPrivacyRequests(accountId:string):Promise<SafePrivacyRequest[]>{
  return withMemberTransaction(accountId,async c=>{
    const r=await c.query('SELECT id,kind,state,created_at FROM privacy_requests WHERE account_id=$1 ORDER BY created_at DESC LIMIT 30',[accountId]);
    return r.rows;
  });
}
export async function requestPrivacyAction(accountId:string,kind:'export'|'delete'|'correct'|'access',key:string):Promise<SafePrivacyRequest>{
  return withMemberTransaction(accountId,async c=>{
    const r=await c.query(`INSERT INTO privacy_requests(account_id,kind,request_key)
      VALUES($1,$2,$3) ON CONFLICT (account_id,request_key) DO NOTHING
      RETURNING id,kind,state,created_at`,[accountId,kind,key]);
    if(r.rows[0])return r.rows[0];
    const prev=await c.query('SELECT id,kind,state,created_at FROM privacy_requests WHERE account_id=$1 AND request_key=$2',[accountId,key]);
    if(prev.rows[0]?.kind!==kind)throw Error('PRIVACY_KEY_CONFLICT');
    return prev.rows[0];
  });
}
