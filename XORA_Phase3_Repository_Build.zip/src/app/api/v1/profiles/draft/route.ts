import type {NextRequest} from 'next/server';
import {features} from '@/lib/env';
import {resolveAccountSession} from '@/lib/session';
import {getMemberDraft,saveMemberDraft} from '@/lib/profile-db';
import {parseProfileDraft} from '@/core/onboarding';
import {sameOrigin} from '@/core/security';
import {requestId,jsonOk,jsonError} from '@/lib/request';
export const runtime='nodejs';
export const dynamic='force-dynamic';
function enabled():boolean{return features.authEnabled && features.profileDraftsEnabled && process.env.XORA_PUBLIC_LAUNCH!=='true' && process.env.XORA_ENVIRONMENT==='staging';}
export async function GET(req:NextRequest){
 const id=requestId();if(!enabled())return jsonError('SERVICE_UNAVAILABLE',503,id);
 try{const user=await resolveAccountSession(req);if(!user)return jsonError('UNAUTHORIZED',401,id);
  return jsonOk({draft:await getMemberDraft(user.accountId)},id);
 }catch{return jsonError('SERVICE_UNAVAILABLE',503,id);}
}
export async function PUT(req:NextRequest){
 const id=requestId();if(!enabled())return jsonError('SERVICE_UNAVAILABLE',503,id);
 if(!sameOrigin(req.headers.get('origin'),process.env.XORA_BASE_URL))return jsonError('FORBIDDEN',403,id);
 if(Number(req.headers.get('content-length')||0)>4096)return jsonError('INVALID_REQUEST',413,id);
 try{const user=await resolveAccountSession(req);if(!user)return jsonError('UNAUTHORIZED',401,id);
  const parsed=parseProfileDraft(await req.json());if(!parsed.ok)return jsonError('INVALID_REQUEST',422,id);
  const draft=await saveMemberDraft(user.accountId,parsed.value);
  if(!draft)return jsonError('CONFLICT',409,id);
  return jsonOk({draft,discovery_enabled:false},id);
 }catch{return jsonError('SERVICE_UNAVAILABLE',503,id);}
}
