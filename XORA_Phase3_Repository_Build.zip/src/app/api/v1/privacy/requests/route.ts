import type {NextRequest} from 'next/server';
import {features} from '@/lib/env';
import {resolveAccountSession} from '@/lib/session';
import {listPrivacyRequests,requestPrivacyAction} from '@/lib/profile-db';
import {sameOrigin} from '@/core/security';
import {requestId,jsonOk,jsonError} from '@/lib/request';
export const runtime='nodejs';
export const dynamic='force-dynamic';
function enabled():boolean{return features.authEnabled && features.privacyRequestsEnabled && process.env.XORA_PUBLIC_LAUNCH!=='true' && process.env.XORA_ENVIRONMENT==='staging';}
export async function GET(req:NextRequest){
 const id=requestId();if(!enabled())return jsonError('SERVICE_UNAVAILABLE',503,id);
 try{const user=await resolveAccountSession(req);if(!user)return jsonError('UNAUTHORIZED',401,id);
  return jsonOk({requests:await listPrivacyRequests(user.accountId)},id);
 }catch{return jsonError('SERVICE_UNAVAILABLE',503,id);}
}
export async function POST(req:NextRequest){
 const id=requestId();if(!enabled())return jsonError('SERVICE_UNAVAILABLE',503,id);
 if(!sameOrigin(req.headers.get('origin'),process.env.XORA_BASE_URL))return jsonError('FORBIDDEN',403,id);
 if(Number(req.headers.get('content-length')||0)>256)return jsonError('INVALID_REQUEST',413,id);
 try{const user=await resolveAccountSession(req);if(!user)return jsonError('UNAUTHORIZED',401,id);
  const body=await req.json();
  if(!body||typeof body!=='object'||Array.isArray(body)||Object.keys(body).length!==1||!['export','delete','correct','access'].includes(body.kind))return jsonError('INVALID_REQUEST',422,id);
  const key=req.headers.get('Idempotency-Key');
  if(!key || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(key))return jsonError('INVALID_REQUEST',422,id);
  const ticket=await requestPrivacyAction(user.accountId,body.kind,key.toLowerCase());
  return jsonOk({ticket},id,201);
 }catch{return jsonError('SERVICE_UNAVAILABLE',503,id);}
}
