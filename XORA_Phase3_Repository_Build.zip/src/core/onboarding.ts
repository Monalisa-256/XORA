/** Strict, dependency-free draft and eligibility policy. No identifying documents or DOB in public profiles. */
export type DatingIntent = 'date' | 'casual' | 'both';
export type ReviewState = 'draft'|'submitted'|'needs_changes'|'approved'|'rejected';
export type AgeDecision = 'pending'|'needs_evidence'|'approved'|'ineligible'|'rejected';
export type PrivacyVisibility = 'hidden'|'visible'|'paused';
export type ProfileDraft = {
  display_name:string;
  broad_area:string;
  intention:DatingIntent;
  bio:string;
  expected_version:number;
};
export type ParseResult = {ok:true;value:ProfileDraft}|{ok:false;code:string};
const EMAIL=/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i;
const PHONE=/(?:\+?256|0)(?:[ .-]?\d){9}\b/;
const URL=/(?:https?:\/\/|www\.|(?:wa\.me|t\.me|bit\.ly)\/)/i;
const CONTROL=/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/u;
const SAFE_NAME=/^[\p{L}\p{M}\p{N}][\p{L}\p{M}\p{N} .'-]*$/u;
const SAFE_AREA=/^[\p{L}\p{M}\p{N}][\p{L}\p{M}\p{N} ,'\-/]*$/u;
function trimmed(v:unknown):string|null{
  if(typeof v!=='string')return null;
  const cleaned=v.normalize('NFKC').trim().replace(/\r\n?/g,'\n');
  return CONTROL.test(cleaned)?null:cleaned;
}
/** Completely reject extra fields so email, DOB, ID number, precise coordinates cannot be saved accidentally. */
export function parseProfileDraft(input:unknown):ParseResult{
  if(!input || typeof input!=='object' || Array.isArray(input))return{ok:false,code:'INVALID_BODY'};
  const o=input as Record<string,unknown>;
  const expected=['display_name','broad_area','intention','bio','expected_version'];
  if(Object.keys(o).length!==expected.length || Object.keys(o).some(k=>!expected.includes(k)))return{ok:false,code:'UNEXPECTED_FIELD'};
  const name=trimmed(o.display_name),area=trimmed(o.broad_area),bio=trimmed(o.bio);
  if(!name||[...name].length<2||[...name].length>40||!SAFE_NAME.test(name))return{ok:false,code:'INVALID_DISPLAY_NAME'};
  if(!area||[...area].length<2||[...area].length>60||!SAFE_AREA.test(area))return{ok:false,code:'INVALID_BROAD_AREA'};
  if(o.intention!=='date'&&o.intention!=='casual'&&o.intention!=='both')return{ok:false,code:'INVALID_INTENTION'};
  if(bio===null||[...bio].length>500)return{ok:false,code:'INVALID_BIO'};
  if([name,area,bio].some(x=>EMAIL.test(x)||PHONE.test(x)||URL.test(x)))return{ok:false,code:'CONTACT_DETAILS_DISALLOWED'};
  if(!Number.isSafeInteger(o.expected_version)||Number(o.expected_version)<0||Number(o.expected_version)>2147483640)return{ok:false,code:'INVALID_VERSION'};
  return{ok:true,value:{display_name:name,broad_area:area,intention:o.intention,bio,expected_version:Number(o.expected_version)}};
}

/** Server-side rule used for any future discovery listing. Default to invisible. */
export function canAppearInDiscovery(input:{accountStatus:string;emailVerified:boolean;adultDecision:AgeDecision|null;reviewState:ReviewState|null;visibility:PrivacyVisibility|null;hasApprovedPhoto:boolean;legalEnabled:boolean}):boolean{
  return input.legalEnabled===true && input.accountStatus==='active' && input.emailVerified===true &&
    input.adultDecision==='approved' && input.reviewState==='approved' && input.visibility==='visible' && input.hasApprovedPhoto===true;
}
/** Explicit mutual intent compatibility; choosing Casual never overrides someone else's Date-only preference. */
export function intentsCompatible(a:DatingIntent,b:DatingIntent):boolean{
  return a==='both'||b==='both'||a===b;
}
export function mayEditDraft(state:ReviewState):boolean{
  return state==='draft'||state==='needs_changes';
}
export function maySubmitProfile(input:{state:ReviewState;validDraft:boolean;emailVerified:boolean;ageDecision:AgeDecision|null;hasApprovedPhoto:boolean}):boolean{
  return input.state==='draft'&&input.validDraft&&input.emailVerified&&input.ageDecision==='approved'&&input.hasApprovedPhoto;
}
