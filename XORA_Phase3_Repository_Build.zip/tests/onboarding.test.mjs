import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseProfileDraft,canAppearInDiscovery,intentsCompatible,mayEditDraft,maySubmitProfile} from '../src/core/onboarding.ts';
const valid={display_name:'Amina N',broad_area:'Kampala',intention:'date',bio:'I enjoy books',expected_version:0};
test('accept valid minimal draft',()=>assert.deepEqual(parseProfileDraft(valid),{ok:true,value:valid}));
for(const [name,change,code] of [
 ['DOB must not be accepted',{date_of_birth:'1990-01-01'},'UNEXPECTED_FIELD'],
 ['private phone must not be accepted',{phone:'0771234567'},'UNEXPECTED_FIELD'],
 ['precise coordinates must not be accepted',{latitude:0.1},'UNEXPECTED_FIELD'],
 ['email cannot be embedded in bio',{bio:'Contact me at a@b.co'},'CONTACT_DETAILS_DISALLOWED'],
 ['phone cannot be embedded in bio',{bio:'Reach me +256 772 123 456'},'CONTACT_DETAILS_DISALLOWED'],
 ['external contact link prohibited',{bio:'Find me at wa.me/256700000000'},'CONTACT_DETAILS_DISALLOWED'],
 ['invalid intention',{intention:'escort'},'INVALID_INTENTION'],
 ['negative version',{expected_version:-1},'INVALID_VERSION'],
 ['excessive version',{expected_version:2147483647},'INVALID_VERSION'],
 ['empty name',{display_name:''},'INVALID_DISPLAY_NAME'],
 ['too long bio',{bio:'a'.repeat(501)},'INVALID_BIO'],
 ['malformed area',{broad_area:'1;DROP TABLE'},'INVALID_BROAD_AREA'],
 ['unsafe Unicode control',{bio:'hello\u0000world'},'INVALID_BIO']
])test(name,()=>assert.deepEqual(parseProfileDraft({...valid,...change}),{ok:false,code}));
test('normalize draft whitespace',()=>assert.equal(parseProfileDraft({...valid,display_name:'  Amina N  '}).ok,true));
const visible={accountStatus:'active',emailVerified:true,adultDecision:'approved',reviewState:'approved',visibility:'visible',hasApprovedPhoto:true,legalEnabled:true};
test('fully eligible, reviewed, consented profile may appear',()=>assert.equal(canAppearInDiscovery(visible),true));
for(const [name,change] of [
 ['unknown or underage adult decision',{adultDecision:'pending'}],
 ['adult needs evidence',{adultDecision:'needs_evidence'}],
 ['ineligible adult',{adultDecision:'ineligible'}],
 ['rejected adult',{adultDecision:'rejected'}],
 ['unreviewed profile',{reviewState:'submitted'}],
 ['draft profile',{reviewState:'draft'}],
 ['paused profile',{visibility:'paused'}],
 ['hidden profile',{visibility:'hidden'}],
 ['unapproved image',{hasApprovedPhoto:false}],
 ['unverified email',{emailVerified:false}],
 ['restricted account',{accountStatus:'restricted'}],
 ['without legal launch approval',{legalEnabled:false}]
])test(`discovery rejects ${name}`,()=>assert.equal(canAppearInDiscovery({...visible,...change}),false));
test('date/casual mismatch rejected',()=>assert.equal(intentsCompatible('date','casual'),false));
test('both matches any intent',()=>{for(const x of ['date','casual','both'])assert.equal(intentsCompatible('both',x),true)});
test('draft and needs-changes can edit only',()=>{assert.equal(mayEditDraft('draft'),true);assert.equal(mayEditDraft('needs_changes'),true);assert.equal(mayEditDraft('approved'),false);assert.equal(mayEditDraft('submitted'),false)});
test('submission needs reviewed adult and approved media',()=>{const b={state:'draft',validDraft:true,emailVerified:true,ageDecision:'approved',hasApprovedPhoto:true};assert.equal(maySubmitProfile(b),true);assert.equal(maySubmitProfile({...b,ageDecision:'pending'}),false);assert.equal(maySubmitProfile({...b,hasApprovedPhoto:false}),false)});
