-- XORA Phase 3 prerelease: private profile drafts and eligibility records.
-- STAGING BRANCH ONLY (br-proud-base-bgx1lcns). No real user onboarding or discovery is enabled.
-- Prerequisite: migrations 0001..0010. Apply as one transaction via a reviewed migration runner.
-- No DOB, identity numbers, phone numbers or exact coordinates are stored in member_profiles.

CREATE TABLE member_profiles (
  account_id uuid PRIMARY KEY REFERENCES accounts(id) ON DELETE RESTRICT,
  display_name text NOT NULL CHECK (char_length(display_name) BETWEEN 2 AND 40),
  broad_area text NOT NULL CHECK (char_length(broad_area) BETWEEN 2 AND 60),
  intention text NOT NULL CHECK (intention IN ('date','casual','both')),
  bio text NOT NULL DEFAULT '' CHECK (char_length(bio) <= 500),
  review_state text NOT NULL DEFAULT 'draft' CHECK (review_state IN ('draft','submitted','needs_changes','approved','rejected')),
  version integer NOT NULL DEFAULT 1 CHECK (version BETWEEN 1 AND 2147483640),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE member_privacy_settings (
  account_id uuid PRIMARY KEY REFERENCES accounts(id) ON DELETE RESTRICT,
  is_discoverable boolean NOT NULL DEFAULT false,
  show_activity boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE adult_eligibility_cases (
  account_id uuid PRIMARY KEY REFERENCES accounts(id) ON DELETE RESTRICT,
  decision text NOT NULL DEFAULT 'pending' CHECK (decision IN ('pending','needs_evidence','approved','ineligible','rejected')),
  evidence_file_id uuid UNIQUE REFERENCES file_objects(id) ON DELETE RESTRICT,
  reviewer_id uuid REFERENCES accounts(id) ON DELETE SET NULL,
  decided_at timestamptz,
  decision_reason_code text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((decision='pending' AND decided_at IS NULL) OR (decision<>'pending'))
);

CREATE TABLE profile_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
  file_id uuid NOT NULL UNIQUE REFERENCES file_objects(id) ON DELETE RESTRICT,
  review_state text NOT NULL DEFAULT 'pending' CHECK(review_state IN ('pending','approved','rejected','removed')),
  is_primary boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES accounts(id) ON DELETE SET NULL
);
CREATE INDEX profile_photos_member_created_idx ON profile_photos(account_id,created_at DESC);
CREATE UNIQUE INDEX profile_photos_single_primary ON profile_photos(account_id) WHERE is_primary AND review_state='approved';

CREATE TABLE profile_review_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
  reviewer_id uuid REFERENCES accounts(id) ON DELETE SET NULL,
  decision text NOT NULL CHECK(decision IN ('submitted','needs_changes','approved','rejected','restricted')),
  reason_code text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX profile_review_events_member_idx ON profile_review_events(account_id,created_at DESC);

CREATE TABLE member_consent_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
  kind text NOT NULL CHECK(kind IN ('terms','privacy_notice','optional_marketing')),
  document_version text NOT NULL CHECK (char_length(document_version) BETWEEN 1 AND 40),
  granted boolean NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT now(),
  request_id text NOT NULL CHECK (char_length(request_id) BETWEEN 1 AND 128),
  UNIQUE(account_id,kind,request_id)
);
CREATE INDEX member_consents_account_idx ON member_consent_events(account_id,recorded_at DESC);

CREATE TABLE privacy_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
  kind text NOT NULL CHECK (kind IN ('export','delete','correct','access')),
  state text NOT NULL DEFAULT 'received' CHECK(state IN ('received','reviewing','identity_check','fulfilled','refused')),
  request_key text NOT NULL CHECK(request_key ~ '^[0-9a-f-]{36}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  UNIQUE(account_id,request_key)
);
CREATE INDEX privacy_requests_by_member_idx ON privacy_requests(account_id,created_at DESC);

-- Database-level discoverability guard: no accidental switch from hidden to public.
CREATE FUNCTION xora_guard_profile_discovery() RETURNS trigger AS $$
BEGIN
  IF NEW.is_discoverable AND NOT EXISTS (
    SELECT 1 FROM accounts a
    JOIN member_profiles p ON p.account_id=a.id
    JOIN adult_eligibility_cases e ON e.account_id=a.id
    WHERE a.id=NEW.account_id AND a.status='active'
      AND p.review_state='approved' AND e.decision='approved'
      AND EXISTS (
        SELECT 1 FROM profile_photos ph
        JOIN file_objects f ON f.id=ph.file_id
        WHERE ph.account_id=a.id AND ph.review_state='approved' AND f.state='confirmed'
      )
  ) THEN
    RAISE EXCEPTION 'XORA_DISCOVERY_GUARD_DENIED' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp;
CREATE TRIGGER member_privacy_discovery_guard BEFORE INSERT OR UPDATE OF is_discoverable
  ON member_privacy_settings FOR EACH ROW EXECUTE FUNCTION xora_guard_profile_discovery();

-- RLS applies to the restricted web runtime role, not table-owner migrations.
ALTER TABLE member_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE member_privacy_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE adult_eligibility_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE member_consent_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE privacy_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE profile_photos ENABLE ROW LEVEL SECURITY;

CREATE POLICY own_profile_read ON member_profiles FOR SELECT TO xora_runtime USING
  (account_id::text = current_setting('xora.actor_account_id',true));
CREATE POLICY own_profile_insert ON member_profiles FOR INSERT TO xora_runtime WITH CHECK
  (account_id::text = current_setting('xora.actor_account_id',true));
CREATE POLICY own_profile_update ON member_profiles FOR UPDATE TO xora_runtime USING
  (account_id::text = current_setting('xora.actor_account_id',true)) WITH CHECK
  (account_id::text = current_setting('xora.actor_account_id',true));

CREATE POLICY own_privacy_read ON member_privacy_settings FOR SELECT TO xora_runtime USING
  (account_id::text = current_setting('xora.actor_account_id',true));
CREATE POLICY own_privacy_insert ON member_privacy_settings FOR INSERT TO xora_runtime WITH CHECK
  (account_id::text = current_setting('xora.actor_account_id',true));
CREATE POLICY own_privacy_update ON member_privacy_settings FOR UPDATE TO xora_runtime USING
  (account_id::text = current_setting('xora.actor_account_id',true)) WITH CHECK
  (account_id::text = current_setting('xora.actor_account_id',true));

CREATE POLICY own_eligibility_read ON adult_eligibility_cases FOR SELECT TO xora_runtime USING
  (account_id::text = current_setting('xora.actor_account_id',true));
CREATE POLICY own_consents_read ON member_consent_events FOR SELECT TO xora_runtime USING
  (account_id::text = current_setting('xora.actor_account_id',true));
CREATE POLICY own_consents_insert ON member_consent_events FOR INSERT TO xora_runtime WITH CHECK
  (account_id::text = current_setting('xora.actor_account_id',true));
CREATE POLICY own_privacy_requests_read ON privacy_requests FOR SELECT TO xora_runtime USING
  (account_id::text = current_setting('xora.actor_account_id',true));
CREATE POLICY own_privacy_requests_insert ON privacy_requests FOR INSERT TO xora_runtime WITH CHECK
  (account_id::text = current_setting('xora.actor_account_id',true));
CREATE POLICY own_photo_read ON profile_photos FOR SELECT TO xora_runtime USING
  (account_id::text = current_setting('xora.actor_account_id',true));

-- Only the server can provide the account-id context, inside a per-request DB transaction.
GRANT SELECT ON member_profiles,member_privacy_settings TO xora_runtime;
GRANT INSERT(account_id,display_name,broad_area,intention,bio) ON member_profiles TO xora_runtime;
GRANT INSERT(account_id,show_activity) ON member_privacy_settings TO xora_runtime;
GRANT UPDATE(display_name,broad_area,intention,bio,version,updated_at) ON member_profiles TO xora_runtime;
GRANT UPDATE(is_discoverable,show_activity,updated_at) ON member_privacy_settings TO xora_runtime;
GRANT SELECT ON adult_eligibility_cases,profile_photos TO xora_runtime;
GRANT SELECT ON member_consent_events,privacy_requests TO xora_runtime;
GRANT INSERT(account_id,kind,document_version,granted,request_id) ON member_consent_events TO xora_runtime;
GRANT INSERT(account_id,kind,request_key) ON privacy_requests TO xora_runtime;

INSERT INTO app_schema_migrations(version,description) VALUES
  ('0011','Privacy-default profile drafts, adult decision separation, consent events, requests, RLS and visibility trigger');
