# XORA Phase 3 increment — privacy-default member onboarding foundation

Date: 22 November 2026. This increment is **not a Phase 3 launch**. It introduces staging-only schema and policy code while authentication, identity/age verification, and legal approval remain gated.

## Completed in source

- An isolated migration for member profiles, broad-area information, separate adult eligibility decisions, consent events, media review, privacy settings and privacy requests.
- Database default `review_state=draft`; default `is_discoverable=false`; database trigger disallows turning discovery on unless adult and profile checks and approved photos are complete.
- Row-level security for the restricted runtime role, with the account UUID set by the trusted server using `set_config` in an explicit transaction; zero rows without this context.
- Column-level restrictions prevent client runtime from setting adult decision and moderation approval fields.
- A versioned draft API with conflict rejection for concurrent writers, strict field allowlisting, server-side member identity, same-origin write protection, no DOB/phone/ID/exact location fields.
- A private account privacy-request API with idempotency keys. Requests queue review instead of automatically deleting data.
- Default-off release flags `XORA_PHASE3_DRAFTS_ENABLED` and `XORA_PRIVACY_REQUESTS_ENABLED`.

## Never conflate

1. Email verification is not adult eligibility.
2. Adult eligibility is not profile moderation.
3. Profile moderation is not photo/media scanning.
4. These checks do not guarantee somebody is safe.
5. Database readiness does not imply legal clearance or permitted public use.

## Rollout and test

1. Run `node --experimental-strip-types --test tests/*.test.mjs`.
2. Apply `migrations/0011_private_onboarding_foundation.sql` **only** to Neon project `sweet-meadow-04731447`, staging branch `br-proud-base-bgx1lcns`, database `xora`. Never auto-run on Neon `main`.
3. Verify RLS without actor GUC returns zero rows; verify a member cannot write an approved review state or discoverable flag.
4. Run `npm ci`, `npm run typecheck`, `npm run build` once a reviewed lockfile exists and dependency installation is available.
5. Only enable the API flags after verified email+Better Auth session tests, test-only staging identity provisioning, DB permissions and case review E2E tests.
6. Leave signup, profile discovery, payments, promotion and member contact disabled.

## Open work

- Approved age-assurance provider and legal/privacy sign-off in Uganda.
- Staff reviewer workflow with least-privilege case evidence access, MFA, and retention schedule.
- Private media scanner and signed image uploads with MIME/content validation.
- User-facing member profile wizard behind authenticated staff-controlled pilot access.
- Security audit, accessible mobile QA, data subject request response process and deletion scheduling.
