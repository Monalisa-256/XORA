# XORA — private onboarding staging evidence (22 November 2026)

## Scope and isolation

- GitHub repository: `Monalisa-256/XORA`; last checked passing ZIP workflow: [run #4](https://github.com/Monalisa-256/XORA/actions/runs/45025957906).
- GitHub branch creation via the connected GitHub integration was **denied with HTTP 403**. Therefore this increment is available as a repository ZIP, **not committed to the remote repo**.
- Neon project `sweet-meadow-04731447`, database `xora`, **staging only** `br-proud-base-bgx1lcns`.
- Main branch `br-young-hill-bgijo9jk` remained unchanged: **2 migrations, 0 accounts, no `member_profiles` table** as independently verified.
- Vercel project `xora-secure-staging`, `prj_CHJUd01GsHX6Nnq5B5mkPcz3ucL2`; deployment protection: **SSO enabled for all deployments**.
- Ready protected preview deployment: `dpl_7wQqvSDH8WfmoAJcsTkS1uyEA33n`, URL `https://xora-secure-staging-im6k7qjs8-kabuusumohammed182-7875s-projects.vercel.app`.

## Actual results

- `migrations/0011_private_onboarding_foundation.sql` committed transactionally to XORA staging. Staging has **29 tables / 11 migrations**.
- Restricted `xora_web_staging` role used for RLS and mutation-negative tests.
- One synthetic member draft saved in staging; **zero visible/discoverable profiles**. No real users onboarded or funds collected.
- Without actor context, RLS SELECT returned 0 drafts. With the other fictional member as actor, reading the draft returned 0 rows.
- Attempting to insert a forged approved profile returned PostgreSQL **42501** (insufficient privilege).
- Attempting to turn discovery on before approval returned PostgreSQL **23514** (check violation).
- Policy test suite: **134/134 passing** (102 previous + 32 profile/eligibility tests).
- ZIP extractor tests: **39 passing**; source boundary scanner passed on 47 TS/TSX files.
- Vercel Next.js 16.4.6 build: **READY**; compiler, TypeScript and route generation passed. The preview includes `/onboarding-preview`, `/api/v1/profiles/draft`, `/api/v1/privacy/requests`.
- The deployed preview is still behind Vercel Authentication. This is a deployment build verification, **not** verified end-to-end login, email sending, staff MFA, or safe media scanning.

## Remains blocked by explicit gates

- The app still has `XORA_AUTH_ENABLED=false`, `XORA_SIGNUP_ENABLED=false`, `XORA_PUBLIC_LAUNCH=false`, and payment flags false. Phase 3 draft/write APIs are disabled by default.
- Test-domain verified transactional email, live Better Auth session tests, age-assurance process, reviewer MFA, consent UX, media scanning and legal/privacy approvals are still required.
- No claim of identity verification, member eligibility, payment-provider authorisation, or production readiness.

## Security notes

- SQL uses RLS tied to a per-transaction actor UUID set by the trusted Node backend. A role without actor context cannot read member rows.
- Database privilege boundaries prevent app writes to review or adult eligibility decisions. The visibility trigger independently denies premature opt-in.
- The static wizard uses only fictional browser-local data. It never stores photos, documents or payments.
- The repository source ZIP is the handoff for the changes that GitHub would not accept through the current integration.
