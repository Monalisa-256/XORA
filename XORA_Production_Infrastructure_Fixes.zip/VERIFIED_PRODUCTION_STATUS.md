# XORA production infrastructure — verified status, 22 November 2026

## Scope and safety

The user authorized the XORA Render workspace and supplied both provider project links. Only XORA resources were changed. Public signups, authentication enrollment, member discovery and payments remain intentionally disabled because the XORA product's Phase 0/1 gates and production integration tests are not complete. No real users were created.

## GitHub — failing workflow diagnosed, not updated

Repository: `Monalisa-256/XORA`, branch `main`.
Failed Actions run #5: https://github.com/Monalisa-256/XORA/actions/runs/45027549491

Cause: the current inline ZIP extractor reads `XORA_GitHub_Ready_Repository.zip` and `XORA_Phase3_Repository_Build.zip` together and raises `ValueError: Conflicting duplicate: .env.example`. They are independent versions, not one archive. The current checked-out repo already has `scripts/zip_guard.py`, `scripts/verify_repo.py` and `tests/test_zip_guard.py`.

Remediation included in this package: `.github/workflows/zip-extract-validate-update.yml`. It tests the existing extracted source, handles each ZIP separately using the existing guard script, runs a Next.js build, validates SHA-256 manifests, and publishes artifacts. Local verification passed: 39 Python tests, 102 Node tests, source boundary checks, and independent ZIP rebuilding/validation of both archives.

**Not applied to GitHub:** connected GitHub calls to update the file and create a repair branch both returned HTTP 403 `Resource not accessible by integration`. Commit the provided workflow using a principal with repository write permission, or reconnect the GitHub integration with the required permissions. Do not deploy an unverified GitHub workflow.

## Render — functioning production service

The original service `XORA` (`srv-dc1f2qt6e07s73d6s4g0`) failed because its start command incorrectly contained `healthCheckPath:`. Its Next.js build had succeeded; the runtime CLI was malformed. This original service is unchanged and still exists.

A separate Render service `xora-production` (`srv-dc1fh74s728c73ca7sng`) now exists in the user's approved workspace. URL: https://xora-production.onrender.com. It is linked to `Monalisa-256/XORA:main`, located in Frankfurt on the free instance plan and Node 22, with command:

`npm run start -- --hostname 0.0.0.0 --port $PORT`

Render service logs explicitly confirmed `Ready in 1693ms` and `Your service is live` for an earlier revision. The latest revision (after the final safe environment updates) was verified as `live` in the provider API. Render public access must not be mistaken for a fully approved product launch.

Production flags are disabled. The service received a restricted XORA Neon `DATABASE_URL`, random Better Auth secret, MFA encryption secret and private monitoring token via server-side environment updates. No secret appears in this archive. The authenticated `/api/health/ready` request has not been observed end-to-end.

## Vercel — production project and deployment

Project ID: `prj_CHJUd01GsHX6Nnq5B5mkPcz3ucL2`, name now `xora-production`. URL: https://xora-production.vercel.app. The project remains linked to `Monalisa-256/XORA:main`. Node 22 is selected. The project retains Vercel Authentication on all environments, so production is **protected**, not public.

The production environment has a restricted Neon connection string and server-only generated secrets, plus app feature flags disabled and both provider origin URLs. **Latest Vercel production redeploy `dpl_DVPS42F2GRGoQmMZ4k9SE97dLJwr` is READY** after updating environment variables; source is GitHub `main` at `69f978e`. Production remains behind Vercel Authentication. Live HTTP checks were not independently authenticated.

## Neon — clean production target

Project `sweet-meadow-04731447`, main branch `br-young-hill-bgijo9jk`, database `xora`. The app login `xora_prod_web` is a least-privilege read-only Postgres login, not the Neon database owner. It was verified to connect and query `accounts`, but cannot insert or delete accounts. At verification the production main branch had zero accounts and only the 14 foundation tables / 2 migrations; do not enable real authentication or user writes until schema and full product security review are complete.

Staging branch and synthetic staging accounts were not used for production.

## What inter-service connectivity actually means

Both providers reference the same XORA production Neon branch and the same GitHub repository, and are configured with each other's origin URLs (`XORA_RENDER_ORIGIN`, `XORA_VERCEL_ORIGIN` etc.). **This does not yet constitute a working frontend-to-backend proxy or verified cross-provider session/authentication contract.** The current Next.js application runs separately on both platforms. A controlled API bridge, shared auth design, transport enforcement, readiness checks and secure CDN/proxy strategy must be implemented and tested before assuming Vercel forwards member traffic to Render.

Also unavailable or not configured: an approved verified-email sender/API key, production S3 object credentials and storage scanning, payment-provider merchant credentials, staff MFA enrollment, end-to-end login tests, legally approved member onboarding, automated deployment release gates, custom production domain. Do not invent these values or flip safety flags.

## Manual GitHub fix (required)

In the `Monalisa-256/XORA` GitHub repository, replace `.github/workflows/zip-extract-validate-update.yml` with the matching file from this archive and commit. Push to `main`, review the Actions logs and require CI verification before production traffic or code promotion. The current integration cannot push this change (HTTP 403).

## Free-plan limitation

The production Render service currently uses the free plan to avoid incurring unapproved paid charges. Free services can suspend when idle and are not a substitute for production availability requirements or comprehensive observability. Upgrading requires explicit cost/plan approval.
