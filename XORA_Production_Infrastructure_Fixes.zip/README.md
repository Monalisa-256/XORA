# XORA Production Infrastructure Repair — 22 November 2026

## Directly confirmed infrastructure

- GitHub repository: `Monalisa-256/XORA`, branch `main`.
- Latest observed GitHub failure (#5): `ValueError: Conflicting duplicate: .env.example`, because the inline workflow attempted to merge two independently versioned ZIP archives. The tested `scripts/zip_guard.py` already handles **each ZIP separately** with repository source authoritative. The replacement workflow is `.github/workflows/zip-extract-validate-update.yml`. It must be placed as `.github/workflows/zip-extract-validate-update.yml`, replacing the existing file.
- GitHub connector could read the repo and logs but rejected **write** operations with `403 Resource not accessible by integration`. The workflow replacement was NOT uploaded to GitHub.
- Original Render service `XORA` (`srv-dc1f2qt6e07s73d6s4g0`) failed after a successful Next.js build because its startup command mistakenly appended `healthCheckPath: /api/health/live` as a literal CLI argument. The current Render connector has no update-service/start-command action. The original service was not deleted.
- New Render production service: `xora-production`, `srv-dc1fh74s728c73ca7sng`, `https://xora-production.onrender.com`; Frankfurt, Node 22, valid `npm run start -- --hostname 0.0.0.0 --port $PORT` command, `main` Git source, auto-deploy enabled. It achieved `live` during testing. The deployment may roll during environment updates.
- Vercel project id `prj_CHJUd01GsHX6Nnq5B5mkPcz3ucL2`, renamed from `xora-secure-staging` to `xora-production`, pinned to Node 22. `https://xora-production.vercel.app` is a verified project domain. Production deployments from Git `Monalisa-256/XORA:main` succeeded. Vercel Authentication protection remains enforced for all deployments.
- Neon project `sweet-meadow-04731447`, **main** branch `br-young-hill-bgijo9jk`, PostgreSQL database `xora`, `xora_prod_web` read-only login. It has no real accounts and currently only the two foundational schema migrations. The staging branch remains separate and is NOT the production target.

## Production variables set by connector

### Vercel production target

`DATABASE_URL`, `BETTER_AUTH_SECRET`, `XORA_INTERNAL_MONITOR_TOKEN` (encrypted sensitive); `XORA_DATABASE_NAME`, `XORA_DATABASE_NEON_PROJECT_ID`, `XORA_DATABASE_NEON_BRANCH_ID`, `XORA_DATABASE_ALLOWED_HOST`, `XORA_DATABASE_ALLOWED_USER`, `XORA_ENVIRONMENT`, `XORA_BASE_URL`, `BETTER_AUTH_URL`, `XORA_RENDER_ORIGIN`, `XORA_VERCEL_ORIGIN`, `XORA_AUTH_ENABLED`, `XORA_SIGNUP_ENABLED`, `XORA_PUBLIC_LAUNCH`, `XORA_TEST_ENDPOINTS`, `XORA_MOMO_PAYMENTS`, `XORA_PHASE3_DRAFTS_ENABLED`, `XORA_PRIVACY_REQUESTS_ENABLED`, `XORA_PROFILE_BUCKET`, `XORA_ELIGIBILITY_BUCKET`, `XORA_PAYMENT_PROOFS_BUCKET`.

### Render production target

Same non-secret variables, `NODE_VERSION=22.16.0`, with current names/URLs matching production. **The Render production service has now received `DATABASE_URL`, `BETTER_AUTH_SECRET`, `XORA_STAFF_MFA_KEY` and `XORA_INTERNAL_MONITOR_TOKEN` through server-side environment updates. Secrets are not stored in this ZIP. The authenticated `/api/health/ready` endpoint still requires a live probe; environment configuration alone does not prove database connectivity.**

To verify Render credentials: open https://dashboard.render.com/web/srv-dc1fh74s728c73ca7sng > Environment and confirm the four secret keys are present without exposing values. Use the restricted `xora_prod_web` role, not `xora_owner`. Keep `XORA_AUTH_ENABLED=false` until the full auth schema and approved email service are ready.

## What "Render connected to Vercel" means here

Both runtimes are built from the same GitHub `main` branch and configured for the same XORA Neon **production** project and branch, and their **origin** variables identify each other. They are not yet a split frontend/backend deployment with a verified inter-service API contract. Both currently run the Next.js app independently; do not turn on the same background worker, payment handler, or session exchange on both services. The authenticated readiness probe and a verified inter-service API contract remain outstanding.

## Workflow installation

Copy `.github/workflows/zip-extract-validate-update.yml` to `.github/workflows/zip-extract-validate-update.yml` in GitHub. This version does not merge ZIPs; it processes all filenames independently with `scripts/zip_guard.py`, runs 39 Python tests plus app tests, compiles Next.js, normalizes files and publishes artifacts. Optional ZIP commits are manual-only to avoid automatic write loops.

The GitHub integration is currently read-only for contents mutation, so **someone with write access must upload this one file**. Do not paste secrets. Do not let a ZIP extractor automatically overwrite reviewed source code or workflow files in production.

## Release gates (NOT COMPLETE)

No public member registration, verified-email delivery, staff MFA enrollment, live payment processing, discovery or messaging have passed production validation. Legal and provider approvals are outstanding. `XORA_AUTH_ENABLED`, `XORA_SIGNUP_ENABLED`, `XORA_PUBLIC_LAUNCH`, and `XORA_MOMO_PAYMENTS` remain `false`. `main` does not yet carry the complete staging database schema.

## Verified caveats

- The original Render `XORA` service has a malformed startup command and remains separate. The new `xora-production` service supersedes it but does not remove it.
- The XORA Neon `main` branch contains only the foundation schema (14 tables, 2 migrations). Production login and payments must not be enabled.
- Vercel production deployment remains behind Vercel Authentication. The Render service is a public web endpoint, but does not accept registrations or payment.
- GitHub `main` still has its failing workflow until someone with repository write access installs the replacement.
- The platform services share repository/DB settings and cross-origin metadata, but a tested request proxy or authenticated service-to-service communication has not yet been implemented.
