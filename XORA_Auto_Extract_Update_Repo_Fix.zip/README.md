# XORA: automatically import any ZIP, validate, and update GitHub

This package fixes the difference between **validating a ZIP** (the previous workflow) and **actually importing it into the Git repository** (the new workflow).

## Install once

Replace `.github/workflows/zip-extract-validate-update.yml` on GitHub `Monalisa-256/XORA` with the replacement YAML in this package, then commit it to `main`. **This single YAML is self-contained**: it bootstraps `scripts/import_repo_zips.py` and `tests/test_import_repo_zips.py`, runs the importer, and commits both tools after the first successful ZIP import. You may alternatively upload all three files in their corresponding paths.

The default GitHub Actions `GITHUB_TOKEN` must be permitted to write repository contents for the isolated `commit` job. Verify GitHub → Settings → Actions → General → Workflow permissions; choose Read and write permissions if allowed by organizational policy. Branch protection must also allow bot commits, or GitHub will reject the push and no archives will be removed from the remote repository. Do not disable branch protection blindly: a PR-based policy is safer for sensitive projects.

## On the next push to main

1. Find **any tracked ZIP**, regardless of filename, case, spaces, or containing directory.
2. Validate archive member paths, compressed size, symlink types, secret-like filenames, and recursive ZIPs.
3. Unwrap unnecessary shared top-level directories while keeping real `src/`, `tests/`, `scripts/`, `docs/`, and `.github/` paths.
4. Merge archive contents into a unique-path worktree. When different archives contain the same path, the most recently committed archive takes precedence; identical duplicates are collapsed. Conflicting duplicates *inside one ZIP*, case collisions, or distinct paths with identical payloads fail safely rather than silently dropping potentially necessary files.
5. Keep the currently executing workflow file intact even if an older ZIP includes it. For partial (change-only) archives, preserve the repository's main README and place any ZIP README under `docs/zip-import-notes/<archive-name>.md`.
6. Run Python unit tests, Node tests, security-boundary checks, dependency installation, and Next.js build, without production secrets.
7. In an isolated job **only after all tests pass**, verify all SHA-256 hashes, stage extracted files, stage removal of original ZIPs, and commit them together to `main`.
8. If any validation, build, permission, branch protection, or push fails, the remote ZIPs remain in GitHub; nothing is falsely reported as imported.

Pull requests run tests read-only and never commit or delete archives.

## Usage

Upload your `name with spaces.ZIP`, `Latest.zip`, or other archive(s) to the GitHub repository and commit. The workflow automatically processes them. Do not manually run the old artifact-only workflow. You can inspect Actions → latest run → **Commit extracted files and remove processed ZIPs**. A fully successful run must show that job green, *not just the first validation job*.

## Security constraints

ZIP extraction never follows symlinks or accepts absolute/traversing paths, sensitive credential filenames, generated dependency/build folders, or nested ZIP remnants. This workflow is intended for trusted pushes to `main`, not automatic acceptance of untrusted third-party source code. Public signup, authentication and payments remain separately gated; the workflow does not enable them.

## Locally verified

- 19 importer integration and safety tests passed.
- Current XORA patch ZIP was imported into a simulated Git repository, with main README and active workflow preserved, new scripts/tests correctly staged, and the original ZIP staged for deletion **after** validation.
- Existing ZIP extractor tests passed (43) after importing the latest patch.
- Two-archive simulation passed (full XORA repository plus newer patch); 153 unique files were retained after deduplication.
- YAML syntax was parsed successfully. Live GitHub commit/job pending user install; connected GitHub write API returned 403 in prior attempts.
